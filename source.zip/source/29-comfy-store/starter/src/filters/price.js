import { getElement } from '../utils.js';
import display from '../displayProducts.js';

const setupPrice = () => {};

export default setupPrice;
