import { getStorageItem, setStorageItem } from './utils.js';
let store = [];
const setupStore = () => {};
const findProduct = () => {};
export { store, setupStore, findProduct };
