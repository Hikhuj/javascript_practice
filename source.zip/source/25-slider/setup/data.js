const people = [
  {
    img: 'https://www.course-api.com/images/people/person-3.jpeg',
    name: 'peter doe',
    job: 'product manager',
    text: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem quoeius recusandae officia voluptas sint deserunt dicta nihil nam omnis? `,
  },
  {
    img: 'https://www.course-api.com/images/people/person-1.jpeg',
    name: 'susan doe',
    job: 'developer',
    text: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem quoeius recusandae officia voluptas sint deserunt dicta nihil nam omnis?`,
  },
  {
    img: 'https://www.course-api.com/images/people/person-2.jpeg',
    name: 'emma doe',
    job: 'designer',
    text: `Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem quoeius recusandae officia voluptas sint deserunt dicta nihil nam omnis?`,
  },
];

export default people;
