console.log('wiki starter');
